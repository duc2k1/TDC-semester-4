<?php
define('BASE_URL', 'be1_mysql');